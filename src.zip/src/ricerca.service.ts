import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RicercaService {

  constructor(private http: HttpClient) { }

  apiKey:string="eab86f42c72b2d4f5c23202ce044c952";
  https:string="https://api.themoviedb.org/3/movie/popular?api_key=eab86f42c72b2d4f5c23202ce044c952";

  searchMovie(term: string): Observable<any> {
    return this.http.get(`https://api.themoviedb.org/3/search/movie?query=` + term +`&api_key=eab86f42c72b2d4f5c23202ce044c952`);
  }
}
